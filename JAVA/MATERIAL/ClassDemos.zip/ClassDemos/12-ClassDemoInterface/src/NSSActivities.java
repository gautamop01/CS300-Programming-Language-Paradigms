
public interface NSSActivities    {
      int extra=5;
public   void bloodDOnation(int hr);

	public   void attendNationalDays(int hr) ;
		
 	
	  
	public  default  void rules()
	{
		System.out.println("Rule1:.......");
		System.out.println("Rule2:.......");
 	}

}
