
public interface Marksheetgen {
public void generate();
}
